package recuperacion;
public class Examen {

}
